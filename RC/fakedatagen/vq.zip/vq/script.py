import varqso as vq
v=vq.VarQso('1/0type1J.fits',band='z')
v.fit('z','DRW')
print loga2, logl
