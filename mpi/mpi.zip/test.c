#include <stdio.h>
int main()
{
	int a, b;
	a=printf("Hello!\n");
	b=printf("%d: Phew! That went okay!\n", a);
	return b;
}
