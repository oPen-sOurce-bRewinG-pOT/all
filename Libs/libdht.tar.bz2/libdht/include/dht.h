#ifndef dht_h
void compute_dht ( int size , double * in , double * out , int order , double rmax ) ;
#endif
