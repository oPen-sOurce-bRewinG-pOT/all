/* objnum.h, this header file contains the number of objects you want to build. */

